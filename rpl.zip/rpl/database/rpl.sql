-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 10, 2024 at 02:10 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rpl`
--

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE `barang` (
  `id_barang` varchar(20) NOT NULL,
  `nama_barang` varchar(200) NOT NULL,
  `jumlah` int(200) NOT NULL,
  `jumlah_awal` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`id_barang`, `nama_barang`, `jumlah`, `jumlah_awal`) VALUES
('BRG-000001', 'Floor Cleaner', 90, 90),
('BRG-000002', 'Glass Shine', 70, 70),
('BRG-000003', 'Multi-Surface Cleaner', 40, 40),
('BRG-000004', 'Disinfectant Spray', 70, 70),
('BRG-000005', 'Carpet Spot Remover', 0, 0),
('BRG-000006', 'Bathroom Cleaner', 40, 40),
('BRG-000007', 'Hand Soap Refill', 130, 140),
('BRG-000008', 'Mold & Mildew Remover', 10, 10),
('BRG-000009', 'abc', 21, -8);

-- --------------------------------------------------------

--
-- Table structure for table `barang_keluar`
--

CREATE TABLE `barang_keluar` (
  `id_keluar` varchar(20) NOT NULL,
  `tanggal_keluar` date NOT NULL,
  `id_barang` varchar(20) NOT NULL,
  `jumlah` int(20) NOT NULL,
  `mitra` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `barang_keluar`
--

INSERT INTO `barang_keluar` (`id_keluar`, `tanggal_keluar`, `id_barang`, `jumlah`, `mitra`) VALUES
('KLR-000001', '2024-12-09', 'BRG-000004', 20, 'PMS-000003'),
('KLR-000002', '2024-12-09', 'BRG-000003', 30, 'PMS-000003'),
('KLR-000003', '2024-12-10', 'BRG-000001', 10, 'PMS-000002'),
('KLR-000004', '2024-12-10', 'BRG-000006', 10, 'PMS-000002'),
('KLR-000005', '2024-12-09', 'BRG-000005', 20, 'PMS-000001'),
('KLR-000006', '2024-12-09', 'BRG-000008', 5, 'PMS-000001'),
('KLR-000007', '2024-12-09', 'BRG-000007', 30, 'PMS-000001');

--
-- Triggers `barang_keluar`
--
DELIMITER $$
CREATE TRIGGER `before_barang_keluar` BEFORE INSERT ON `barang_keluar` FOR EACH ROW BEGIN
    DECLARE prefix VARCHAR(4);
    DECLARE new_id INT;

    -- Set prefix untuk id_keluar
    SET prefix = 'KLR-';

    -- Ambil ID terakhir dari kolom id_keluar
    SET new_id = (SELECT IFNULL(MAX(CAST(SUBSTRING_INDEX(id_keluar, '-', -1) AS UNSIGNED)), 0) + 1 
                  FROM barang_keluar);

    -- Gabungkan prefix dengan ID baru
    SET NEW.id_keluar = CONCAT(prefix, LPAD(new_id, 6, '0'));
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `barang_masuk`
--

CREATE TABLE `barang_masuk` (
  `id_masuk` varchar(20) NOT NULL,
  `id_order` varchar(20) NOT NULL,
  `id_barang` varchar(20) NOT NULL,
  `jumlah` int(200) NOT NULL,
  `tanggal_masuk` date NOT NULL,
  `mitra` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `barang_masuk`
--

INSERT INTO `barang_masuk` (`id_masuk`, `id_order`, `id_barang`, `jumlah`, `tanggal_masuk`, `mitra`) VALUES
('MSK-000001', 'ORD-000004', 'BRG-000007', 30, '2024-12-03', 'PYD-000001'),
('MSK-000002', 'ORD-000001', 'BRG-000003', 30, '2024-12-02', 'PYD-000002'),
('MSK-000003', 'ORD-000006', 'BRG-000002', 40, '2024-12-03', 'PYD-000001'),
('MSK-000004', 'ORD-000002', 'BRG-000001', 50, '2024-12-05', 'PYD-000002'),
('MSK-000005', 'ORD-000005', 'BRG-000004', 30, '2024-12-02', 'PYD-000003'),
('MSK-000006', 'ORD-000003', 'BRG-000007', 30, '2024-12-05', 'PYD-000001');

--
-- Triggers `barang_masuk`
--
DELIMITER $$
CREATE TRIGGER `before_masuk` BEFORE INSERT ON `barang_masuk` FOR EACH ROW BEGIN
    DECLARE prefix VARCHAR(4);
    DECLARE new_id INT;

    -- Set prefix untuk id_masuk
    SET prefix = 'MSK-';

    -- Ambil ID terakhir dari kolom id_masuk dan ambil bagian numeriknya
    SET new_id = (SELECT IFNULL(MAX(CAST(SUBSTRING_INDEX(id_masuk, '-', -1) AS UNSIGNED)), 0) + 1 
                  FROM barang_masuk);

    -- Gabungkan prefix dengan ID baru
    SET NEW.id_masuk = CONCAT(prefix, LPAD(new_id, 6, '0'));
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `detail_order`
--

CREATE TABLE `detail_order` (
  `id_order` varchar(20) NOT NULL,
  `id_barang` varchar(20) NOT NULL,
  `jumlah` int(200) NOT NULL,
  `harga` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `detail_order`
--

INSERT INTO `detail_order` (`id_order`, `id_barang`, `jumlah`, `harga`) VALUES
('ORD-000001', 'BRG-000003', 20, 22000),
('ORD-000002', 'BRG-000001', 30, 20000),
('ORD-000003', 'BRG-000007', 40, 15000),
('ORD-000005', 'BRG-000004', 30, 30000),
('ORD-000006', 'BRG-000002', 20, 25000),
('ORD-000004', 'BRG-000007', 40, 15000);

-- --------------------------------------------------------

--
-- Table structure for table `mitra_pemesan`
--

CREATE TABLE `mitra_pemesan` (
  `id_mitra` varchar(20) NOT NULL,
  `nama_mitra` varchar(200) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `kontak` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mitra_pemesan`
--

INSERT INTO `mitra_pemesan` (`id_mitra`, `nama_mitra`, `alamat`, `kontak`) VALUES
('PMS-000001', 'Hartono Mall', 'Jl. Ir. Sutami No. 100, Surakarta ', '0271-888999 '),
('PMS-000002', 'Solo Square', 'Jl. Slamet Riyadi No. 451, Surakarta', '0271-736890'),
('PMS-000003', 'RS Indriati', 'Jl. Palem Raya No. 1, Solo Baru, Sukoharjo', '0271-672333');

--
-- Triggers `mitra_pemesan`
--
DELIMITER $$
CREATE TRIGGER `before_mitra_pemesan` BEFORE INSERT ON `mitra_pemesan` FOR EACH ROW BEGIN
    DECLARE prefix VARCHAR(4);
    DECLARE new_id INT;

    -- Set prefix untuk id_keluar
    SET prefix = 'PMS-';

    -- Ambil ID terakhir dan increment dengan 1
    SET new_id = (SELECT COALESCE(MAX(CAST(SUBSTRING_INDEX(id_mitra, '-', -1) AS UNSIGNED)), 0) + 1
                  FROM mitra_pemesan);

    -- Gabungkan prefix dengan ID baru dan set nilai NEW.id_keluar
    SET NEW.id_mitra = CONCAT(prefix, LPAD(new_id, 6, '0'));
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `mitra_penyedia`
--

CREATE TABLE `mitra_penyedia` (
  `id_mitra` varchar(10) NOT NULL,
  `nama_mitra` varchar(100) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `kontak` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mitra_penyedia`
--

INSERT INTO `mitra_penyedia` (`id_mitra`, `nama_mitra`, `alamat`, `kontak`) VALUES
('PYD-000001', 'UD Solo Cleaning Supplies', 'Jl. Dr. Radjiman No. 23, Surakarta', '0857-1234-5678'),
('PYD-000002', 'Graha Pembersih Solo ', 'Jl. Bhayangkara No. 19, Surakarta ', '0821-2345-6789'),
('PYD-000003', 'PT Solo Multi Supplies', 'Jl. Ir. Sutami No. 28, Surakarta', '0811-5678-9012'),
('PYD-000004', 'Toko Amanah Bersih', 'Pasar Klewer Blok C7, Surakarta', '0856-7890-1234');

--
-- Triggers `mitra_penyedia`
--
DELIMITER $$
CREATE TRIGGER `before_mitra_penyedia` BEFORE INSERT ON `mitra_penyedia` FOR EACH ROW BEGIN
    DECLARE prefix VARCHAR(4);
    DECLARE new_id INT;

    -- Set prefix untuk id_keluar
    SET prefix = 'PYD-';

    -- Ambil ID terakhir dan increment dengan 1
    SET new_id = (SELECT COALESCE(MAX(CAST(SUBSTRING_INDEX(id_mitra, '-', -1) AS UNSIGNED)), 0) + 1
                  FROM mitra_penyedia);

    -- Gabungkan prefix dengan ID baru dan set nilai NEW.id_keluar
    SET NEW.id_mitra = CONCAT(prefix, LPAD(new_id, 6, '0'));
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `order_barang`
--

CREATE TABLE `order_barang` (
  `id_order` varchar(20) NOT NULL,
  `tanggal_order` date NOT NULL,
  `total_harga` int(200) NOT NULL,
  `mitra` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_barang`
--

INSERT INTO `order_barang` (`id_order`, `tanggal_order`, `total_harga`, `mitra`) VALUES
('ORD-000001', '2024-12-02', 1760000, 'PYD-000002'),
('ORD-000002', '2024-12-01', 600000, 'PYD-000002'),
('ORD-000003', '2024-12-01', 600000, 'PYD-000001'),
('ORD-000004', '2024-12-02', 600000, 'PYD-000001'),
('ORD-000005', '2024-12-02', 900000, 'PYD-000003'),
('ORD-000006', '2024-12-02', 500000, 'PYD-000001');

--
-- Triggers `order_barang`
--
DELIMITER $$
CREATE TRIGGER `before_order` BEFORE INSERT ON `order_barang` FOR EACH ROW BEGIN
    DECLARE prefix VARCHAR(4);
    DECLARE new_id INT;

    -- Set prefix untuk id_order
    SET prefix = 'ORD-';

    -- Ambil ID terakhir dari kolom id_order
    SET new_id = (SELECT IFNULL(MAX(CAST(SUBSTRING_INDEX(id_order, '-', -1) AS UNSIGNED)), 0) + 1 
                  FROM order_barang);

    -- Gabungkan prefix dengan ID baru
    SET NEW.id_order = CONCAT(prefix, LPAD(new_id, 6, '0'));
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `username` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `username`, `password`, `nama`, `email`) VALUES
(1, 'fifi', '123', 'Agus Salim', 'ww@m.com'),
(2, 'Devina', '1234', 'Devina Arroyan', '2208096047@student.walisongo.ac.id');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`id_barang`);

--
-- Indexes for table `barang_keluar`
--
ALTER TABLE `barang_keluar`
  ADD KEY `id_barang` (`id_barang`),
  ADD KEY `mitra` (`mitra`);

--
-- Indexes for table `barang_masuk`
--
ALTER TABLE `barang_masuk`
  ADD PRIMARY KEY (`id_masuk`),
  ADD KEY `mitra` (`mitra`),
  ADD KEY `id_order` (`id_order`),
  ADD KEY `id_barang` (`id_barang`);

--
-- Indexes for table `detail_order`
--
ALTER TABLE `detail_order`
  ADD KEY `id_barang` (`id_barang`),
  ADD KEY `id_order` (`id_order`);

--
-- Indexes for table `mitra_pemesan`
--
ALTER TABLE `mitra_pemesan`
  ADD PRIMARY KEY (`id_mitra`);

--
-- Indexes for table `mitra_penyedia`
--
ALTER TABLE `mitra_penyedia`
  ADD PRIMARY KEY (`id_mitra`);

--
-- Indexes for table `order_barang`
--
ALTER TABLE `order_barang`
  ADD PRIMARY KEY (`id_order`),
  ADD KEY `mitra` (`mitra`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
