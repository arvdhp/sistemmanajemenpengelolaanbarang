<?php
include('koneksi.php');

// Ambil id_barang dari parameter GET
$id_barang = $_GET['id_barang'];

// Cek apakah id_barang digunakan di tabel order_barang
$query_check_order = "SELECT COUNT(*) AS count FROM detail_order WHERE id_barang = '$id_barang'";
$result_check_order = mysqli_query($konek_db, $query_check_order);
$row_check_order = mysqli_fetch_assoc($result_check_order);

// Cek apakah id_barang digunakan di tabel barang_masuk
$query_check_barang_masuk = "SELECT COUNT(*) AS count FROM barang_masuk WHERE id_barang = '$id_barang'";
$result_check_barang_masuk = mysqli_query($konek_db, $query_check_barang_masuk);
$row_check_barang_masuk = mysqli_fetch_assoc($result_check_barang_masuk);

// Cek apakah id_barang digunakan di tabel barang_keluar
$query_check_barang_keluar = "SELECT COUNT(*) AS count FROM barang_keluar WHERE id_barang = '$id_barang'";
$result_check_barang_keluar = mysqli_query($konek_db, $query_check_barang_keluar);
$row_check_barang_keluar = mysqli_fetch_assoc($result_check_barang_keluar);

// Jika id_barang ditemukan di salah satu tabel, beri peringatan
if ($row_check_order['count'] > 0 || $row_check_barang_masuk['count'] > 0 || $row_check_barang_keluar['count'] > 0) {
    echo "<script>alert('Barang tidak dapat dihapus karena masih digunakan di tabel lain!');</script>";
    echo "<script>window.history.back();</script>"; // Kembali ke halaman sebelumnya
} else {
    // Jika id_barang tidak ditemukan di ketiga tabel, lanjutkan dengan penghapusan
    $query_delete = "DELETE FROM barang WHERE id_barang = '$id_barang'";
    if (mysqli_query($konek_db, $query_delete)) {
        echo "<script>alert('Barang berhasil dihapus!');</script>";
        header("Location: daftar barang.php"); // Redirect ke halaman daftar barang
    } else {
        echo "<script>alert('Terjadi kesalahan saat menghapus barang.');</script>";
    }
}
?>
