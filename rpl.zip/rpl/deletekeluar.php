<?php
include('koneksi.php');

// Ambil ID barang_keluar yang akan dihapus
$id_keluar = $_GET['id_keluar'];

// Ambil data dari tabel barang_keluar untuk mendapatkan id_barang dan jumlahnya
$query = "SELECT id_barang, jumlah FROM barang_keluar WHERE id_keluar = '$id_keluar'";
$result = mysqli_query($konek_db, $query);

if ($row = mysqli_fetch_assoc($result)) {
    $id_barang = $row['id_barang'];
    $jumlah_dikeluarkan = $row['jumlah'];

    // Mengambil jumlah barang saat ini dari tabel barang
    $query_jumlah = "SELECT jumlah FROM barang WHERE id_barang = '$id_barang'";
    $result_jumlah = mysqli_query($konek_db, $query_jumlah);

    if ($row_jumlah = mysqli_fetch_assoc($result_jumlah)) {
        $jumlah_sekarang = $row_jumlah['jumlah'];

        // Tambah jumlah barang yang keluar
        $jumlah_baru = $jumlah_sekarang + $jumlah_dikeluarkan;

        // Update jumlah barang di tabel barang
        $query_update_jumlah = "UPDATE barang SET jumlah = '$jumlah_baru' WHERE id_barang = '$id_barang'";
        mysqli_query($konek_db, $query_update_jumlah);
    }

    // Hapus data barang_keluar yang sesuai dengan id_keluar
    $query_delete = "DELETE FROM barang_keluar WHERE id_keluar = '$id_keluar'";
    mysqli_query($konek_db, $query_delete);

    // Redirect setelah berhasil menghapus
    header("Location: barang keluar.php");
} else {
    // Jika tidak ditemukan data yang sesuai, lakukan redirect atau tampilkan pesan error
    echo "Data tidak ditemukan!";
}
?>
