<?php
include('koneksi.php');

// Ambil ID barang dan jumlah barang yang akan dihapus
$id_masuk = $_GET['id_masuk'];

// Ambil data dari tabel barang_masuk untuk mendapatkan id_barang dan jumlahnya
$query = "SELECT id_barang, jumlah FROM barang_masuk WHERE id_masuk = '$id_masuk'";
$result = mysqli_query($konek_db, $query);

if ($row = mysqli_fetch_assoc($result)) {
    $id_barang = $row['id_barang'];
    $jumlah_dihapus = $row['jumlah'];

    // Mengambil jumlah barang saat ini dari tabel barang
    $query_jumlah = "SELECT jumlah FROM barang WHERE id_barang = '$id_barang'";
    $result_jumlah = mysqli_query($konek_db, $query_jumlah);

    if ($row_jumlah = mysqli_fetch_assoc($result_jumlah)) {
        $jumlah_sekarang = $row_jumlah['jumlah'];

        // Kurangi jumlah barang yang ada sesuai dengan jumlah yang dihapus
        $jumlah_baru = $jumlah_sekarang - $jumlah_dihapus;

        // Update jumlah barang di tabel barang
        $query_update_jumlah = "UPDATE barang SET jumlah = '$jumlah_baru' WHERE id_barang = '$id_barang'";
        mysqli_query($konek_db, $query_update_jumlah);
    }

    // Hapus data barang_masuk yang sesuai dengan id_masuk
    $query_delete = "DELETE FROM barang_masuk WHERE id_masuk = '$id_masuk'";
    mysqli_query($konek_db, $query_delete);

    // Redirect setelah berhasil menghapus
    header("Location: barang masuk.php");
} else {
    // Jika tidak ditemukan data yang sesuai, lakukan redirect atau tampilkan pesan error
    echo "Data tidak ditemukan!";
}
?>

