<?php
// Ambil id_order dari URL
$id_order = $_GET['id_order'];

// Include file koneksi ke database
include('koneksi.php');

// Hapus data dari detail_order terlebih dahulu
$sql2 = "DELETE FROM detail_order WHERE id_order='$id_order'";
mysqli_query($konek_db, $sql2);

// Hapus data dari order_barang setelah detail_order dihapus
$sql1 = "DELETE FROM order_barang WHERE id_order='$id_order'";
mysqli_query($konek_db, $sql1);

// Redirect ke halaman order_barang.php setelah data dihapus
header("Location:order barang.php");
?>
