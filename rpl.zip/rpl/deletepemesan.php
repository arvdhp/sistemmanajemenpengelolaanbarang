<?php
include('koneksi.php');

// Ambil id_mitra dari parameter GET
$id_mitra = $_GET['id_mitra'];

// Cek apakah id_mitra digunakan di tabel lain (misalnya, tabel barang_keluar)
$query_check = "SELECT COUNT(*) AS count FROM barang_keluar WHERE mitra = '$id_mitra'";
$result_check = mysqli_query($konek_db, $query_check);
$row_check = mysqli_fetch_assoc($result_check);

// Jika id_mitra ditemukan di tabel barang_keluar, beri peringatan
if ($row_check['count'] > 0) {
    echo "<script>alert('Mitra tidak dapat dihapus karena masih digunakan di tabel Barang Keluar.');</script>";
    echo "<script>window.history.back();</script>"; // Kembali ke halaman sebelumnya
} else {
    // Jika id_mitra tidak ditemukan di tabel lain, lanjutkan dengan penghapusan
    $query_delete = "DELETE FROM mitra_pemesan WHERE id_mitra = '$id_mitra'";
    if (mysqli_query($konek_db, $query_delete)) {
        echo "<script>alert('Mitra berhasil dihapus!');</script>";
        header("Location: mitra.php"); // Redirect ke halaman mitra
    } else {
        echo "<script>alert('Terjadi kesalahan saat menghapus mitra.');</script>";
    }
}
?>
