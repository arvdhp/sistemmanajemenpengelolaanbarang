<?php
include('koneksi.php');

// Ambil id_mitra dari parameter GET
$id_mitra = $_GET['id_mitra'];

// Cek apakah id_mitra digunakan di tabel order_barang
$query_check_order = "SELECT COUNT(*) AS count FROM order_barang WHERE mitra = '$id_mitra'";
$result_check_order = mysqli_query($konek_db, $query_check_order);
$row_check_order = mysqli_fetch_assoc($result_check_order);

// Cek apakah id_mitra digunakan di tabel barang_masuk
$query_check_barang_masuk = "SELECT COUNT(*) AS count FROM barang_masuk WHERE mitra = '$id_mitra'";
$result_check_barang_masuk = mysqli_query($konek_db, $query_check_barang_masuk);
$row_check_barang_masuk = mysqli_fetch_assoc($result_check_barang_masuk);

// Jika id_mitra ditemukan di salah satu tabel, beri peringatan
if ($row_check_order['count'] > 0 || $row_check_barang_masuk['count'] > 0) {
    echo "<script>alert('Mitra tidak dapat dihapus karena masih digunakan di tabel order barang atau barang masuk.');</script>";
    echo "<script>window.history.back();</script>"; // Kembali ke halaman sebelumnya
} else {
    // Jika id_mitra tidak ditemukan di kedua tabel, lanjutkan dengan penghapusan
    $query_delete = "DELETE FROM mitra_penyedia WHERE id_mitra = '$id_mitra'";
    if (mysqli_query($konek_db, $query_delete)) {
        echo "<script>alert('Mitra berhasil dihapus!');</script>";
        header("Location: mitra.php"); // Redirect ke halaman mitra
    } else {
        echo "<script>alert('Terjadi kesalahan saat menghapus mitra.');</script>";
    }
}
?>
