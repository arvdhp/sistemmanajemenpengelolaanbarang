<?php
include 'koneksi.php'; // Koneksi ke database

if (isset($_GET['id_order']) && isset($_GET['id_barang'])) {
    $id_order = $_GET['id_order'];
    $id_barang = $_GET['id_barang'];

    // Query untuk mendapatkan data barang terkait id_order
    $queryBarang = "SELECT detail_order.id_barang, barang.nama_barang
                    FROM detail_order
                    JOIN barang ON detail_order.id_barang = barang.id_barang
                    WHERE detail_order.id_order = '$id_order'";
    $resultBarang = mysqli_query($konek_db, $queryBarang);

    // Periksa apakah query berhasil
    if (!$resultBarang) {
        echo "Error: " . mysqli_error($konek_db);  // Debugging jika ada error
        exit;
    }

    $barang = [];
    while ($row = mysqli_fetch_assoc($resultBarang)) {
        $barang[] = $row; // Tambahkan setiap barang ke array
    }

    // Query untuk memeriksa apakah kombinasi id_order dan id_barang sudah ada di tabel barang_masuk
    $queryCheck = "SELECT * FROM barang_masuk WHERE id_order = '$id_order' AND id_barang = '$id_barang'";
    $resultCheck = mysqli_query($konek_db, $queryCheck);
    
    // Cek apakah kombinasi id_order dan id_barang sudah ada
    $exists = mysqli_num_rows($resultCheck) > 0;

    // Query untuk mendapatkan mitra dan id_mitra terkait id_order
    $queryMitra = "SELECT mitra_penyedia.id_mitra, mitra_penyedia.nama_mitra
                   FROM order_barang
                   JOIN mitra_penyedia ON order_barang.mitra = mitra_penyedia.id_mitra
                   WHERE order_barang.id_order = '$id_order'";
    $resultMitra = mysqli_query($konek_db, $queryMitra);

    $mitra = mysqli_fetch_assoc($resultMitra);

    // Gabungkan data barang, mitra, dan status exists dalam satu respons
    echo json_encode([
        "exists" => $exists, // Flag untuk menunjukkan apakah sudah ada
        "barang" => $barang,
        "mitra" => $mitra
    ]);
} else {
    echo json_encode([
        "exists" => false,
        "barang" => [],
        "mitra" => null
    ]);
}
?>
