<?php
// Pastikan Anda sudah terhubung dengan database
include 'koneksi.php';

// Ambil id_order dari parameter GET
$id_order = $_GET['id_order'];

if ($id_order) {
    // Query untuk mengambil data barang berdasarkan id_order
    $query = "SELECT b.id_barang, b.nama_barang FROM barang b 
              JOIN order_barang ob ON b.id_barang = ob.id_barang 
              WHERE ob.id_order = '$id_order'";

    $result = mysqli_query($konek_db, $query);

    $barang = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $barang[] = $row;
    }

    // Ambil data mitra terkait id_order
    $mitra_query = "SELECT m.id_mitra, m.nama_mitra FROM mitra m 
                    JOIN order_barang ob ON m.id_mitra = ob.id_mitra 
                    WHERE ob.id_order = '$id_order' LIMIT 1";
    $mitra_result = mysqli_query($konek_db, $mitra_query);
    $mitra = mysqli_fetch_assoc($mitra_result);

    // Mengirimkan data barang dan mitra dalam format JSON
    echo json_encode([
        'barang' => $barang,
        'mitra' => $mitra
    ]);
}
?>
