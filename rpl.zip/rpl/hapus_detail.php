<?php
require_once 'koneksi.php'; // Pastikan file koneksi database ada

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_order = $_POST['id_order'];
    $id_barang = $_POST['id_barang'];

    // Validasi input
    if (!empty($id_order) && !empty($id_barang)) {
        $query = "DELETE FROM detail_order WHERE id_order = ? AND id_barang = ?";
        $stmt = $konek_db->prepare($query);
        $stmt->bind_param("ss", $id_order, $id_barang);

        if ($stmt->execute()) {
            echo json_encode(["success" => true]);
        } else {
            echo json_encode(["success" => false, "message" => "Gagal menghapus data."]);
        }

        $stmt->close();
    } else {
        echo json_encode(["success" => false, "message" => "Data tidak valid."]);
    }
} else {
    echo json_encode(["success" => false, "message" => "Metode tidak diizinkan."]);
}
?>
