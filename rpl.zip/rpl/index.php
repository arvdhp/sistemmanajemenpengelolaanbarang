<?php
session_start();
if(isset($_SESSION['login'])){
  header('Location: dashboard_admin.php');
}else{
  header('Location: dashboard.php');
}
?>