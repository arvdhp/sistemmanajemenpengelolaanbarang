<?php
$dbhost = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "rpl";

$konek_db = mysqli_connect($dbhost, $dbusername, $dbpassword,  $dbname);
