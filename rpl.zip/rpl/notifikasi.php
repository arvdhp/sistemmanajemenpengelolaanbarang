<?php
// Ambang batas jumlah minimal untuk stok menipis
include('koneksi.php');
$min_jumlah = 15;
$habis_jumlah = 0;

// Query untuk memeriksa jumlah barang yang menipis dan habis
$query = "SELECT id_barang, nama_barang, jumlah FROM barang WHERE jumlah <= $min_jumlah";
$result = mysqli_query($konek_db, $query);

// Array untuk menyimpan notifikasi
$notifikasi = '';
while ($row = mysqli_fetch_assoc($result)) {
    // Cek jika jumlah barang habis
    if ($row['jumlah'] == $habis_jumlah) {
        $notifikasi .= '
        <li class="mb-2">
            <a class="dropdown-item border-radius-md" href="javascript:;">
                <div class="d-flex py-1">
                    <div class="my-auto">
                        <i class="fa fa-bell me-3" style="font-size: 20px; color: red;"></i>
                    </div>
                    <div class="d-flex flex-column justify-content-center">
                        <h6 class="text-sm font-weight-normal mb-1">
                            <span class="font-weight-bold text-danger">Stok Habis:</span> ' . $row['nama_barang'] . '
                        </h6>
                        <p class="text-xs text-secondary mb-0 ">
                            <i class="fa fa-clock me-1"></i>
                            Barang habis, segera restock
                        </p>
                    </div>
                </div>
            </a>
        </li>';
    } 
    // Cek jika jumlah barang menipis
    elseif ($row['jumlah'] < $min_jumlah) {
        $notifikasi .= '
        <li class="mb-2">
            <a class="dropdown-item border-radius-md" href="javascript:;">
                <div class="d-flex py-1">
                    <div class="my-auto">
                        <i class="fa fa-bell me-3" style="font-size: 20px; color: maroon;"></i>
                    </div>
                    <div class="d-flex flex-column justify-content-center">
                        <h6 class="text-sm font-weight-normal mb-1">
                            <span class="font-weight-bold text-warning">Stok Menipis:</span> ' . $row['nama_barang'] . '
                        </h6>
                        <p class="text-xs text-secondary mb-0 ">
                            <i class="fa fa-clock me-1"></i>
                            Jumlah tersisa: ' . $row['jumlah'] . ' pcs
                        </p>
                    </div>
                </div>
            </a>
        </li>';
    }
}

// Menampilkan notifikasi jika ada stok yang habis atau menipis
if ($notifikasi != '') {
    echo $notifikasi;
} else {
    echo '<li><p class="text-center">Semua barang cukup jumlah</p></li>';
}
?>
