<?php
include('koneksi.php');

// Query untuk mengambil data jumlah dan memperbarui jumlah_awal
$query_update = "UPDATE barang SET jumlah_awal = jumlah";
$result_update = mysqli_query($konek_db, $query_update);

if ($result_update) {
    echo '<script>
            alert("Stok awal bulan berhasil diperbarui!");
            window.location.href="daftar barang.php"; // Redirect ke halaman daftar barang
          </script>';
    exit;
} else {
    echo '<script>
            alert("Gagal memperbarui stok awal bulan: ' . mysqli_error($konek_db) . '");
            window.history.back(); // Kembali ke halaman sebelumnya jika gagal
          </script>';
}
?>
