// search.js
document.getElementById("searchInput").addEventListener("input", function() {
    let filter = this.value.toLowerCase(); // Ambil nilai input pencarian dan ubah menjadi huruf kecil
    let rows = document.querySelectorAll("#dataTable tbody tr"); // Ambil semua baris tabel
    
    rows.forEach(row => {
        let text = row.textContent || row.innerText; // Ambil teks dari seluruh baris
        if (text.toLowerCase().indexOf(filter) > -1) {
            row.style.display = ""; // Tampilkan baris jika cocok
        } else {
            row.style.display = "none"; // Sembunyikan baris jika tidak cocok
        }
    });
});
