<?php
session_start(); // Hanya satu kali memanggil session_start

// Bagian pertama: Memeriksa dan mengambil data dari sesi pengguna
if (isset($_SESSION['login_user'])) {
    // Menyimpan data pengguna yang sedang login
    $user_check = $_SESSION['login_user'];
    include "koneksi.php"; // Koneksi ke database

    // Query untuk mengambil data pengguna berdasarkan username
    $sql = "SELECT * FROM user WHERE username='$user_check'";
    $ses = mysqli_query($konek_db, $sql);
    $row = mysqli_fetch_assoc($ses);
    $login_session = $row['nama'];
} else {
    // Jika sesi login_user tidak ada, tampilkan pesan atau lakukan tindakan lain
    echo "Pengguna belum login.";
}

// Bagian kedua: Menyimpan rentang tanggal ke sesi jika diterima melalui request JSON
$data = json_decode(file_get_contents('php://input'), true);

// Jika data start dan end ada dalam permintaan, simpan ke sesi
if (isset($data['start'], $data['end'])) {
    $_SESSION['start_date'] = $data['start'];
    $_SESSION['end_date'] = $data['end'];
    echo json_encode(['success' => true]); // Tambahkan ini
    exit; // Pastikan untuk keluar setelah mengirim respons
}
?>
