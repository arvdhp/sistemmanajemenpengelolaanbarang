<?php
session_start();

// Ambil data dari request body
$data = json_decode(file_get_contents('php://input'), true);

if (isset($data['start'], $data['end'])) {
    // Simpan data ke session
    $_SESSION['start_date'] = $data['start'];
    $_SESSION['end_date'] = $data['end'];

    // Beri respon sukses
    echo json_encode(['success' => true]);
} else {
    // Beri respon gagal
    echo json_encode(['success' => false, 'message' => 'Tanggal tidak lengkap.']);
}
